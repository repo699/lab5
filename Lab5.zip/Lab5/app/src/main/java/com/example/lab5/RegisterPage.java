package com.example.lab5;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class RegisterPage extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register_page);

        EditText usnr=findViewById(R.id.usnr);
        EditText passr=findViewById(R.id.passr);
        database db=new database(this);
        Button registerBtn=findViewById(R.id.registerBtn);

        registerBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String usernameR=usnr.getText().toString();
                String passwordR=passr.getText().toString();

                try{

                    boolean state=db.InsertData(usernameR,passwordR);

                    if(state){
                        Toast.makeText(getApplicationContext(),"Registered Succesfully", Toast.LENGTH_SHORT).show();

                    }else{
                        Toast.makeText(getApplicationContext(),"Username already exists", Toast.LENGTH_SHORT).show();

                    }

                }catch (Exception e){
                    e.printStackTrace();
                    Toast.makeText(getApplicationContext(),"Username already exists", Toast.LENGTH_SHORT).show();

                }

            }
        });

    }
}