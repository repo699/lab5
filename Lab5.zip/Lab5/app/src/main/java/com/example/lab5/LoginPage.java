package com.example.lab5;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class LoginPage extends AppCompatActivity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login_page);

        Button loginBtn=findViewById(R.id.loginBtn);
        EditText usn=findViewById(R.id.usn);
        EditText pass=findViewById(R.id.pass);
        database db=new database(this);

        loginBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String username=usn.getText().toString();
                String password=pass.getText().toString();

                try{
                    boolean state=db.GetData(username,password);
                    if(state){
                        Toast.makeText(getApplicationContext(),"Welcome "+username, Toast.LENGTH_SHORT).show();
                    }else{
                        Toast.makeText(getApplicationContext(),"Invalid Username or password! ", Toast.LENGTH_SHORT).show();
                    }
                }catch(Exception e){
                    e.printStackTrace();
                }


            }
        });
    }
}