package com.example.lab5;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

public class database  extends SQLiteOpenHelper {


    public database(Context context) {
        super(context, "user", null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("create table user (username TEXT , password TEXT)");

    }


    public boolean InsertData(String username , String password){

        SQLiteDatabase db=this.getWritableDatabase();

        try{

            ContentValues contentValues=new ContentValues();
            contentValues.put("username",username);
            contentValues.put("password",password);
            long result=db.insert("user",null,contentValues);

            if(result==-1){
                return false;
            }else{
                return true;
            }


        }catch(Exception e){
            e.printStackTrace();
            return false;
                   }

    }

    public boolean GetData(String username , String password){
        SQLiteDatabase db=this.getReadableDatabase();

        try{
            Cursor cr = db.rawQuery("select * from user where username='" + username + "' and password=='"+password+"'", null);
            if(cr.getCount()==0){
            return false;
            }else{
                return true;

            }
        }catch(Exception e){
            e.printStackTrace();
            return false;
        }
    }


    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

    }
}
